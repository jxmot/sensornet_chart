

## Our Backers and supporters

Financial contributions to ApexCharts go towards ongoing development costs, servers, etc. You can join them in supporting ApexCharts development by visiting our page on [Patreon](https://www.patreon.com/junedchhipa)!


### Backers
Support us with a monthly donation and help us continue our activities. [[Become a backer](https://www.patreon.com/join/junedchhipa/checkout?rid=3043800)].

Backer on | Name
-----|-----
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=10265776" target="_blank">Taillefer Brice</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=17096169" target="_blank">Thomas Janotta</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/calinou/creators" target="_blank">Hugo Locurcio</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=25422807" target="_blank">Aslan Mutaf</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=3900260" target="_blank">Bob</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=15111755" target="_blank">Pierre Aguilar</a>
<img src="https://c10.patreonusercontent.com/3/eyJ3IjoyMDB9/patreon-media/p/user/11313403/3f4cbd5acdc24f309482cfbf23bfcd81/1.jpe?token-time=2145916800&token-hash=sCMYDL4SDg2xLm64lAWWrM_IyTT6nln8ecgBqvThZeA%3D" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=11313403" target="_blank">Gergo Santha</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=10458746" target="_blank">Xavier Trabet</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=21350037" target="_blank">Richard Klingler</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=9758306" target="_blank">Christopher Bartling</a>
<img src="https://apexcharts.com/media/patron.png" width="16" height="16" /> | <a href="https://www.patreon.com/user/creators?u=39489027" target="_blank">Andrew Pyle</a>

